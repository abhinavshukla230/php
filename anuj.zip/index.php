
<!DOCTYPE html>
<html>
<head>
	<title>form validation</title>
	<style>
		form{
			text-align: center;
			margin-top: 200px;
		}
	</style>
</head>
<body>
<form action="form_post.php" method="POST">
	Username:<br/>
	<input type="text" name="username"><br/>
	Email:<br/>
	<input type="email" name="email"><br/>
	Comments:<br/>
	<textarea name="comments" placeholder="Comments"></textarea><br/>

	<input type="submit" name="submit">
</form>
</body>
</html>